package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FourthSetActivity extends AppCompatActivity {
    Button squatsButton;
    Button pushupsButton;
    Button chinupsButton;
    int squatsAmount;
    int pushupsAmount;
    int chinupsAmount;


    int tappedCircle;

    public void workoutDone(View view){
        Intent intent = new Intent(getApplicationContext(), StretchActivity.class);
        intent.putExtra("tappedCircle", tappedCircle);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.workout);

        Intent intetnt = getIntent();
        tappedCircle = intetnt.getIntExtra("tappedCircle", 0);

        if(tappedCircle % 2 == 0){
            squatsAmount = 84 + 9*(tappedCircle/2);
            pushupsAmount = 56 + 6*(tappedCircle/2);
            chinupsAmount = 28 + 3*(tappedCircle/2);

            switch(squatsAmount % 4){
                case 0:
                    squatsAmount = squatsAmount / 4; break;
                case 1:
                    squatsAmount = squatsAmount / 4 + 1; break;
                case 2:
                    squatsAmount = squatsAmount / 4 + 1; break;
                case 3:
                    squatsAmount = squatsAmount / 4 + 1; break;
            }
            switch(pushupsAmount % 4){
                case 0:
                    pushupsAmount = pushupsAmount / 4; break;
                case 1:
                    pushupsAmount = pushupsAmount / 4 + 1; break;
                case 2:
                    pushupsAmount = pushupsAmount / 4 + 1; break;
                case 3:
                    pushupsAmount = pushupsAmount / 4 + 1; break;
            }
            switch(chinupsAmount % 4){
                case 0:
                    chinupsAmount = chinupsAmount / 4; break;
                case 1:
                    chinupsAmount = chinupsAmount / 4 + 1; break;
                case 2:
                    chinupsAmount = chinupsAmount / 4 + 1; break;
                case 3:
                    chinupsAmount = chinupsAmount / 4 + 1; break;
            }

        } else {
            squatsAmount = 30;
            pushupsAmount = 20;
            chinupsAmount = 10;
        }
        squatsButton = findViewById(R.id.squatsButton);
        pushupsButton = findViewById(R.id.pushupsButton);
        chinupsButton = findViewById(R.id.chinupsButton);
        String squatsButtonText = String.format("%d  SQUATS", squatsAmount);
        String pushupsButtonText = String.format("%d  PUSHUPS", pushupsAmount);
        String chinupsButtonText = String.format("%d  CHINUPS", chinupsAmount);
        squatsButton.setText(squatsButtonText);
        pushupsButton.setText(pushupsButtonText);
        chinupsButton.setText(chinupsButtonText);

    }
}